module Robo_Rally {
	requires java.desktop;
}