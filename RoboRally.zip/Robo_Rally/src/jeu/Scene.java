package jeu;

import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JPanel;

public class Scene extends JPanel{
	
	//VARIABLE
	private ImageIcon icoBandeFond;
	private Image imgBandeFond;
	
	

}
